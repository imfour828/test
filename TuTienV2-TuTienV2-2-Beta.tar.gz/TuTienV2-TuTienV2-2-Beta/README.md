# TuTienV2

TuTienV2 là một plugin đơn giản, cung cấp chế độ chơi theo thể loại tu tiên (tiên hiệp giả tưởng theo truyện và phim).

TuTienV2 is a simple plugin, providing a game mode according to the tu tien genre (fantasy fairy tale based on stories and movies).
